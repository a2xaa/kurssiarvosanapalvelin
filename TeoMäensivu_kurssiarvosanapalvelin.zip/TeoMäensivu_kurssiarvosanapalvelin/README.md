Asentaminen
- kloonaa repositorio
- aja `npm install`
- käynnistä palvelin `node index.js`

Jatkokehitys / tehtävänanto
- muokkaa front-end-koodia siten että kaikki TODO:t tulee täytetyksi
- lisätehtävä: muokkaa ulkoasua paremman näköiseksi
  
